from django.utils import timezone

from courses.models import EmailLog

from .transport import send_email
from .types import RenderedEmail


def record_email_failure(
    *,
    email_type,
    recipient,
    subject,
    error,
    order=None,
    quiz_attempt=None,
):
    """
    Zapíše neúspěšný e-mailový krok do společné EmailLog historie.

    Používá se jak pro chyby transportu, tak pro chyby přípravy
    e-mailu před samotným transportem (například generování PDF).
    """
    return EmailLog.objects.create(
        email_type=email_type,
        recipient=recipient,
        subject=subject,
        status=EmailLog.STATUS_FAILED,
        error_message=str(error),
        order=order,
        quiz_attempt=quiz_attempt,
    )


def deliver_email(
    email: RenderedEmail,
    *,
    email_type,
    order=None,
    quiz_attempt=None,
):
    """
    Předá sestavený e-mail aktivnímu transportu
    a zaznamená výsledek do EmailLog.

    Samotný obsah e-mailu ani přílohy se do databáze
    neukládají.
    """
    try:
        result = send_email(email)
    except Exception as exc:
        record_email_failure(
            email_type=email_type,
            recipient=email.recipient,
            subject=email.subject,
            error=exc,
            order=order,
            quiz_attempt=quiz_attempt,
        )
        raise

    if result.status == "preview":
        status = EmailLog.STATUS_PREVIEW
        sent_at = None

    elif result.status == "sent":
        status = EmailLog.STATUS_SENT
        sent_at = timezone.now()

    else:
        error = ValueError(
            f"Neznámý stav doručení e-mailu: {result.status}"
        )
        record_email_failure(
            email_type=email_type,
            recipient=email.recipient,
            subject=email.subject,
            error=error,
            order=order,
            quiz_attempt=quiz_attempt,
        )
        raise error

    log = EmailLog.objects.create(
        email_type=email_type,
        recipient=email.recipient,
        subject=email.subject,
        status=status,
        order=order,
        quiz_attempt=quiz_attempt,
        sent_at=sent_at,
    )

    return log
