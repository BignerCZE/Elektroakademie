from datetime import date

from django import forms
from django.contrib.auth import password_validation
from django.core.exceptions import ValidationError

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.db.models import Q
from django.forms import BaseFormSet

User = get_user_model()

class ParticipantForm(forms.Form):
    first_name = forms.CharField(
        label="Jméno",
        max_length=150,
        widget=forms.TextInput(
            attrs={
                "placeholder": "Jméno",
                "autocomplete": "given-name",
            }
        ),
    )

    last_name = forms.CharField(
        label="Příjmení",
        max_length=150,
        widget=forms.TextInput(
            attrs={
                "placeholder": "Příjmení",
                "autocomplete": "family-name",
            }
        ),
    )

    email = forms.EmailField(
        label="E-mail",
        widget=forms.EmailInput(
            attrs={
                "placeholder": "E-mail",
                "autocomplete": "email",
            }
        ),
    )

class BaseParticipantFormSet(BaseFormSet):
    def clean(self):
        super().clean()

        if any(self.errors):
            return

        used_emails = set()

        for form in self.forms:
            if not form.cleaned_data:
                continue

            email = form.cleaned_data.get("email")

            if not email:
                continue

            normalized_email = email.strip().lower()

            if normalized_email in used_emails:
                form.add_error(
                    "email",
                    (
                        "Tato e-mailová adresa je v objednávce "
                        "uvedena vícekrát."
                    ),
                )
                continue

            used_emails.add(normalized_email)

            if User.objects.filter(
                email__iexact=normalized_email
            ).exists():
                form.add_error(
                    "email",
                    (
                        "Účet s touto e-mailovou adresou "
                        "již existuje."
                    ),
                )
                
class BillingForm(forms.Form):
    ico = forms.CharField(
        label="IČO",
        required=False,
        max_length=8,
        widget=forms.TextInput(
            attrs={
                "placeholder": "IČO (nepovinné)",
                "inputmode": "numeric",
                "maxlength": "8",
                "autocomplete": "organization",
            }
        ),
    )

    dic = forms.CharField(
        label="DIČ",
        required=False,
        max_length=20,
        widget=forms.TextInput(
            attrs={
                "placeholder": "DIČ (nepovinné)",
            }
        ),
    )

    company_name = forms.CharField(
        label="Název firmy nebo jméno",
        max_length=255,
        widget=forms.TextInput(
            attrs={
                "placeholder": "Název firmy nebo jméno *",
                "autocomplete": "organization",
            }
        ),
    )

    street = forms.CharField(
        label="Ulice a č.p.",
        max_length=255,
        widget=forms.TextInput(
            attrs={
                "placeholder": "Ulice a č.p. *",
                "autocomplete": "street-address",
            }
        ),
    )

    city = forms.CharField(
        label="Město",
        max_length=120,
        widget=forms.TextInput(
            attrs={
                "placeholder": "Město *",
                "autocomplete": "address-level2",
            }
        ),
    )

    zip_code = forms.CharField(
        label="PSČ",
        max_length=20,
        widget=forms.TextInput(
            attrs={
                "placeholder": "PSČ *",
                "autocomplete": "postal-code",
            }
        ),
    )

    country = forms.ChoiceField(
        label="Země",
        choices=[
            ("CZ", "Česká republika"),
            ("SK", "Slovensko"),
        ],
        initial="CZ",
    )

    contact_first_name = forms.CharField(
        label="Jméno kontaktní osoby",
        max_length=100,
        widget=forms.TextInput(
            attrs={
                "placeholder": "Jméno *",
                "autocomplete": "given-name",
            }
        ),
    )

    contact_last_name = forms.CharField(
        label="Příjmení kontaktní osoby",
        max_length=100,
        widget=forms.TextInput(
            attrs={
                "placeholder": "Příjmení *",
                "autocomplete": "family-name",
            }
        ),
    )

    contact_phone_prefix = forms.CharField(
        label="Předvolba",
        max_length=8,
        initial="+420",
        widget=forms.TextInput(
            attrs={
                "placeholder": "+420",
                "inputmode": "tel",
                "autocomplete": "tel-country-code",
            }
        ),
    )

    contact_phone = forms.CharField(
        label="Telefonní číslo",
        max_length=30,
        widget=forms.TextInput(
            attrs={
                "placeholder": "Telefonní číslo *",
                "inputmode": "tel",
                "autocomplete": "tel-national",
            }
        ),
    )

    contact_email = forms.EmailField(
        label="E-mail kontaktní osoby",
        widget=forms.EmailInput(
            attrs={
                "placeholder": "E-mail *",
                "autocomplete": "email",
            }
        ),
    )

    note = forms.CharField(
        label="Poznámka",
        required=False,
        widget=forms.Textarea(
            attrs={
                "placeholder": "Poznámka k objednávce (nepovinné)",
            }
        ),
    )

    def clean_ico(self):
        ico = self.cleaned_data.get("ico", "").strip()

        if not ico:
            return ""

        normalized_ico = "".join(character for character in ico if character.isdigit())

        if len(normalized_ico) != 8:
            raise forms.ValidationError("IČO musí obsahovat přesně 8 číslic.")

        return normalized_ico

    def clean_contact_phone_prefix(self):
        prefix = self.cleaned_data.get("contact_phone_prefix", "").strip()

        if not prefix:
            raise forms.ValidationError("Vyplňte telefonní předvolbu.")

        normalized_prefix = prefix.replace(" ", "")

        if not normalized_prefix.startswith("+"):
            normalized_prefix = f"+{normalized_prefix}"

        if not normalized_prefix[1:].isdigit():
            raise forms.ValidationError("Telefonní předvolba není platná.")

        return normalized_prefix

    def clean_contact_phone(self):
        phone = self.cleaned_data.get("contact_phone", "").strip()

        normalized_phone = (
            phone.replace(" ", "")
            .replace("-", "")
            .replace("/", "")
        )

        if not normalized_phone.isdigit():
            raise forms.ValidationError("Telefonní číslo může obsahovat pouze číslice.")

        if len(normalized_phone) < 7:
            raise forms.ValidationError("Telefonní číslo je příliš krátké.")

        return normalized_phone
    

class ParticipantActivationForm(forms.Form):
    password1 = forms.CharField(
        label="Heslo",
        strip=False,
        error_messages={
            "required": "Zadejte heslo.",
        },
        widget=forms.PasswordInput(
            attrs={
                "placeholder": "Zadejte heslo",
                "autocomplete": "new-password",
            }
        ),
    )

    password2 = forms.CharField(
        label="Potvrzení hesla",
        strip=False,
        error_messages={
            "required": "Zadejte heslo ještě jednou.",
        },
        widget=forms.PasswordInput(
            attrs={
                "placeholder": "Zadejte heslo znovu",
                "autocomplete": "new-password",
            }
        ),
    )

    birth_day = forms.IntegerField(
        label="Den",
        min_value=1,
        max_value=31,
        error_messages={
            "required": "Vyplňte den.",
            "invalid": "Den musí být číslo.",
            "min_value": "Den musí být od 1 do 31.",
            "max_value": "Den musí být od 1 do 31.",
        },
        widget=forms.TextInput(
            attrs={
                "placeholder": "15",
                "inputmode": "numeric",
                "autocomplete": "bday-day",
                "list": "birth-day-options",
            }
        ),
    )

    birth_month = forms.IntegerField(
        label="Měsíc",
        min_value=1,
        max_value=12,
        error_messages={
            "required": "Vyplňte měsíc.",
            "invalid": "Měsíc musí být číslo.",
            "min_value": "Měsíc musí být od 1 do 12.",
            "max_value": "Měsíc musí být od 1 do 12.",
        },
        widget=forms.TextInput(
            attrs={
                "placeholder": "7",
                "inputmode": "numeric",
                "autocomplete": "bday-month",
                "list": "birth-month-options",
            }
        ),
    )

    birth_year = forms.IntegerField(
        label="Rok",
        min_value=1900,
        max_value=date.today().year,
        error_messages={
            "required": "Vyplňte rok.",
            "invalid": "Rok musí být číslo.",
            "min_value": "Zadejte rok čtyřmi číslicemi.",
            "max_value": "Rok narození nemůže být v budoucnosti.",
        },
        widget=forms.TextInput(
            attrs={
                "placeholder": "1982",
                "inputmode": "numeric",
                "autocomplete": "bday-year",
                "list": "birth-year-options",
            }
        ),
    )

    birth_place = forms.CharField(
        label="Místo narození",
        max_length=150,
        widget=forms.TextInput(
            attrs={
                "placeholder": "Místo narození",
            }
        ),
    )

    permanent_address = forms.CharField(
        label="Trvalé bydliště",
        max_length=255,
        widget=forms.TextInput(
            attrs={
                "placeholder": "Ulice, číslo, město, PSČ",
                "autocomplete": "street-address",
            }
        ),
    )

    employer_name = forms.CharField(
        label="Zaměstnavatel",
        max_length=255,
        required=False,
        widget=forms.TextInput(
            attrs={
                "placeholder": "Název zaměstnavatele",
                "autocomplete": "organization",
            }
        ),
    )

    employer_address = forms.CharField(
        label="Adresa zaměstnavatele",
        max_length=255,
        required=False,
        widget=forms.TextInput(
            attrs={
                "placeholder": "Adresa zaměstnavatele",
            }
        ),
    )

    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.user = user
        self.birth_year_options = range(
            date.today().year,
            1899,
            -1,
        )

    def clean_password2(self):
        password1 = self.cleaned_data.get("password1")
        password2 = self.cleaned_data.get("password2")

        if password1 and password2 and password1 != password2:
            raise forms.ValidationError(
                "Zadaná hesla se neshodují."
            )

        return password2

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password1")

        birth_day = cleaned_data.get("birth_day")
        birth_month = cleaned_data.get("birth_month")
        birth_year = cleaned_data.get("birth_year")

        if all(
            value is not None
            for value in (birth_day, birth_month, birth_year)
        ):
            try:
                cleaned_data["birth_date"] = date(
                    birth_year,
                    birth_month,
                    birth_day,
                )
            except ValueError:
                self.add_error(
                    "birth_day",
                    "Zadané datum narození neexistuje.",
                )

        if password:
            try:
                password_validation.validate_password(
                    password,
                    user=self.user,
                )
            except ValidationError as error:
                self.add_error(
                    "password1",
                    error,
                )

        return cleaned_data
