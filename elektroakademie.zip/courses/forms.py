from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser


class CustomUserCreationForm(forms.ModelForm):
    username = forms.CharField(
        label="Jméno",
        widget=forms.TextInput(attrs={"placeholder": "Michael"})
    )

    email = forms.EmailField(
        label="E-mail",
        required=True,
        widget=forms.EmailInput(attrs={"placeholder": "michael.cermak92@gmail.com"})
    )

    class Meta:
        model = CustomUser
        fields = ["username", "email"]